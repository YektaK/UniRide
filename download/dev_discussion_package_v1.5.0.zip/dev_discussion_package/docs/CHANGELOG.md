# 📋 Değişiklik Günlüğü

> **Proje:** UniRide - Engelli Öğrenci Taşımacılık Sistemi  
> **Son Güncelleme:** 27 Mart 2026 - Saat 10:15

---

## [1.5.0] - 27 Mart 2026

### ✨ Eklendi (Added)

#### Yeni Stratejiler - Bağımsız Holistik Çözücüler

| Dosya | Açıklama |
|-------|----------|
| `strategies/vroom_strategy.py` | VROOM ultra-hızlı C++ çözücü (15.8 KB) |
| `strategies/pyvrp_strategy.py` | PyVRP - DIMACS 2021 birincisi HGS (19.2 KB) |

**VROOM Özellikleri:**
- Ultra-hızlı: 1000+ nokta < 5 saniye
- PDPTW (Pickup-Delivery) desteği
- Multi-trip desteği
- OSRM entegrasyonu
- Canlı rota planlama için ideal
- Heterojen fleet native destek (Sw/So kapasite)
- Time window desteği

**PyVRP Özellikleri:**
- DIMACS 2021 Challenge birincisi
- Hybrid Genetic Search (HGS) algoritması
- Heterojen fleet native destek
- Time windows native destek
- En yüksek çözüm kalitesi
- Multi-depot destek
- Akademik referans kalitesinde

#### Güncellenen Dosyalar

| Dosya | Değişiklik |
|-------|------------|
| `strategies/__init__.py` | Yeni stratejiler eklendi, `get_available_solvers()`, `get_recommended_strategy()` fonksiyonları eklendi |

#### Test Dosyaları

| Dosya | Açıklama |
|-------|----------|
| `tests/test_new_strategies.py` | VROOM ve PyVRP test ve karşılaştırma script'i (9.3 KB) |

#### Dokümantasyon

| Dosya | Açıklama |
|-------|----------|
| `docs/CHANGELOG.md` | Bu değişiklik günlüğü |
| `docs/IMPLEMENTATION_STATUS.md` | Uygulama durumu takibi |
| `docs/CHANGES_SUMMARY.md` | Değişiklik özeti |

---

### 🔧 Değişen (Changed)

#### Strategy Registry Güncellemesi

**Yeni kayıtlar:**
```python
# VROOM
"vroom": VROOMStrategy
"vroom_fallback": VROOMFallbackStrategy

# PyVRP
"pyvrp": PyVRPStrategy
"pyvrp_alt": PyVRPAlternativeStrategy
"hgs": PyVRPStrategy  # Alias
```

**Yeni yardımcı fonksiyonlar:**
- `get_available_solvers()` - Kurulu kütüphane durumunu döndürür
- `get_recommended_strategy(n_students, priority)` - Önerilen algoritmayı döndürür

**Öneri mantığı:**
```
N ≤ 10  → permutation_tsp (quality) / greedy (speed)
N ≤ 30  → pyvrp (quality) / ortools (speed) / pso (balanced)
N ≤ 100 → pyvrp (quality) / vroom (speed) / hho (balanced)
N > 100 → pyvrp (quality) / vroom (speed+balanced)
```

---

### 📊 Algoritma Karşılaştırması

| Algoritma | N≤30 | N≤100 | N>100 | Kullanım |
|-----------|------|-------|-------|----------|
| **VROOM** | ⚡ Hızlı | ⚡ Çok hızlı | ⚡ Ultra hızlı | Canlı rota |
| **PyVRP** | 🏆 En iyi kalite | 🏆 En iyi kalite | ✅ İyi | Offline plan |
| OR-Tools | ✅ İyi | ✅ İyi | ✅ İyi | Referans |
| GA/PSO/HHO/GWO | ✅ İyi | ⚠️ Yavaş | ❌ Çok yavaş | Pipeline A |

---

### 📦 Kurulum Gereksinimleri

```bash
# Mevcut (kurulu olmalı)
pip install ortools

# Yeni - VROOM (opsiyonel ama önerilen)
pip install pyvroom

# Yeni - PyVRP (opsiyonel ama önerilen)
pip install pyvrp
```

---

### 🧪 Test Komutları

```bash
cd dev_discussion_package/code
python -m tests.test_new_strategies
```

---

## [1.4.0] - 26 Mart 2026

### Eklendi
- `docs/ARCHITECTURE.md` - Çift pipeline mimarisi
- `docs/ALGORITHM_COMPARISON.md` - Algoritma karşılaştırması
- `docs/ANALYSIS.md` - Mevcut durum analizi
- `README.md` - Geliştirici tartışma paketi

### Tespit Edilen Sorunlar
- K-Means time matrix duyarsızlığı
- Tek öğrencilik rotalar (%15-20)
- Katı küme sınırları

---

## Gelecek Sürümler

### [1.6.0] - Planlanıyor

- `strategies/split_decoder.py` - DP tabanlı Split Decoder
- `strategies/hybrid_base_strategy.py` - Split base class
- `strategies/pso_split_strategy.py` - PSO + Split
- `strategies/hho_split_strategy.py` - HHO + Split
- `strategies/gwo_split_strategy.py` - GWO + Split
- `strategies/ga_split_strategy.py` - GA + Split

### [2.0.0] - İleriki

- Faz 2: Veri kalıcılığı
- Faz 3: İş akışı otomasyonu
- Faz 4: Canlı takip

---

## Sürüm Notları

| Sürüm | Tarih | Özellik |
|-------|-------|---------|
| 1.5.0 | 27.03.2026 | VROOM + PyVRP entegrasyonu |
| 1.4.0 | 26.03.2026 | Dokümantasyon güncellemesi |
| 1.3.0 | 25.03.2026 | Local search modülü |
| 1.2.0 | 24.03.2026 | K-Means clustering |
| 1.1.0 | 24.03.2026 | Base strategy pattern |
| 1.0.0 | 23.03.2026 | İlk sürüm |
