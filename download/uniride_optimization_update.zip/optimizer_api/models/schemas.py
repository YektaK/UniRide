"""
Optimization API Schemas
Pydantic models for request/response validation
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from enum import Enum


class DisabilityType(str, Enum):
    SW = "Sw"  # Wheelchair
    SO = "So"  # Walking


class LocalSearchType(str, Enum):
    """Available local search types for optimization"""
    TWO_OPT = "two_opt"
    THREE_OPT = "three_opt"
    OR_OPT = "or_opt"
    HYBRID = "hybrid"
    NONE = "none"


class LocationNode(BaseModel):
    id: str = Field(..., description="Unique identifier for the location, e.g., 'Sw1', 'So5', 'D.Kampus'")
    lat: float = Field(..., description="Latitude coordinate")
    lng: float = Field(..., description="Longitude coordinate")
    type: str = Field(default="So", description="Type of node: 'Sw' (Wheelchair), 'So' (Walking)")


class StudentNode(BaseModel):
    id: str = Field(..., description="Student ID")
    name: str = Field(default="", description="Student name")
    location_code: str = Field(..., description="Location code e.g., 'Sw1', 'So5'")
    coordinates: Optional[Dict[str, float]] = Field(default=None, description="Lat/lng coordinates")
    disability_type: str = Field(default="So", description="'Sw' or 'So'")


class RouteStep(BaseModel):
    location1: str
    location2: str
    duration: float = Field(description="Travel time in minutes")
    distance: float = Field(default=0.0, description="Travel distance in meters")


class VehicleRoute(BaseModel):
    vehicle_id: str
    route_details: List[RouteStep]
    total_duration_minutes: float
    total_distance_km: float = Field(default=0.0)
    sw_count: int = Field(default=0, description="Number of wheelchair students")
    so_count: int = Field(default=0, description="Number of walking students")
    student_ids: List[str] = Field(default_factory=list, description="IDs of students in this route")


class GAConfig(BaseModel):
    """Genetic Algorithm configuration"""
    population_size: int = Field(default=50, description="Population size")
    max_iterations: int = Field(default=100, description="Maximum iterations")
    crossover_rate: float = Field(default=0.85, ge=0, le=1, description="Crossover rate")
    mutation_rate: float = Field(default=0.15, ge=0, le=1, description="Mutation rate")
    elite_count: int = Field(default=2, description="Number of elites to preserve")
    tournament_size: int = Field(default=3, description="Tournament selection size")
    local_search_type: str = Field(default="two_opt", description="Local search type")
    local_search_rate: float = Field(default=0.1, ge=0, le=1, description="Local search application rate")


class PSOConfig(BaseModel):
    """Particle Swarm Optimization configuration"""
    swarm_size: int = Field(default=30, description="Swarm size")
    max_iterations: int = Field(default=100, description="Maximum iterations")
    inertia_weight: float = Field(default=0.729, ge=0, le=2, description="Inertia weight")
    cognitive_weight: float = Field(default=1.49445, ge=0, description="Cognitive weight (c1)")
    social_weight: float = Field(default=1.49445, ge=0, description="Social weight (c2)")
    local_search_type: str = Field(default="two_opt", description="Local search type")
    local_search_rate: float = Field(default=0.1, ge=0, le=1, description="Local search application rate")


class GWOConfig(BaseModel):
    """Grey Wolf Optimizer configuration"""
    population_size: int = Field(default=30, description="Population size")
    max_iterations: int = Field(default=100, description="Maximum iterations")
    initial_a: float = Field(default=2.0, description="Initial 'a' parameter")
    exploration_rate: float = Field(default=0.5, ge=0, le=1, description="Exploration rate")
    local_search_probability: float = Field(default=0.3, ge=0, le=1, description="Local search probability")
    max_no_improvement: int = Field(default=25, description="Early stopping threshold")
    local_search_type: str = Field(default="two_opt", description="Local search type")


class HHOConfig(BaseModel):
    """Harris Hawks Optimization configuration"""
    population_size: int = Field(default=30, description="Population size")
    max_iterations: int = Field(default=100, description="Maximum iterations")
    initial_energy: float = Field(default=2.0, description="Initial energy")
    levy_flight_beta: float = Field(default=1.5, description="Levy flight beta parameter")
    jump_probability: float = Field(default=0.5, ge=0, le=1, description="Jump probability")
    local_search_intensity: float = Field(default=0.3, ge=0, le=1, description="Local search intensity")
    max_no_improvement: int = Field(default=25, description="Early stopping threshold")
    local_search_type: str = Field(default="two_opt", description="Local search type")


class TwoOptConfig(BaseModel):
    """Two-Opt Strategy configuration"""
    local_search_type: str = Field(default="two_opt", description="Local search type")
    multi_start: bool = Field(default=True, description="Enable multi-start optimization")
    num_starts: int = Field(default=5, description="Number of random starts")
    max_iterations: int = Field(default=30, description="Max iterations per local search")
    intensification: bool = Field(default=True, description="Final intensification phase")


class OptimizationRequest(BaseModel):
    algorithm: str = Field(default="genetic_algorithm", description="Algorithm: genetic_algorithm, pso, gwo, hho, greedy, kmeans_tsp, ortools_cvrp, permutation_tsp, two_opt")
    students: List[StudentNode] = Field(..., description="List of students needing pickup")
    depot: LocationNode = Field(..., description="The depot node (e.g., D.Kampus)")
    max_travel_time: int = Field(default=120, description="Maximum tour time per vehicle in minutes")
    sw_capacity: int = Field(default=4, description="Wheelchair capacity per vehicle")
    so_capacity: int = Field(default=5, description="Walking student capacity per vehicle")
    clustering_algorithm: str = Field(default="kmeans", description="Clustering algorithm for multi-vehicle")

    # Local search type (global setting)
    local_search_type: Optional[str] = Field(default=None, description="Global local search type override")

    # Algorithm-specific parameters
    ga_config: Optional[Dict[str, Any]] = Field(default=None, description="GA parameters")
    pso_config: Optional[Dict[str, Any]] = Field(default=None, description="PSO parameters")
    gwo_config: Optional[Dict[str, Any]] = Field(default=None, description="GWO parameters")
    hho_config: Optional[Dict[str, Any]] = Field(default=None, description="HHO parameters")
    two_opt_config: Optional[Dict[str, Any]] = Field(default=None, description="2-Opt parameters")


class OptimizationResponse(BaseModel):
    algorithm_used: str
    success: bool
    routes: List[VehicleRoute]
    total_vehicles: int = Field(default=0)
    total_duration_minutes: float = Field(default=0.0)
    error_message: Optional[str] = None
    execution_time_seconds: float = Field(default=0.0)


class CompareRequest(BaseModel):
    """Request for comparing all algorithms"""
    students: List[StudentNode] = Field(..., description="List of students needing pickup")
    depot: LocationNode = Field(..., description="The depot node")
    max_travel_time: int = Field(default=120)
    sw_capacity: int = Field(default=4)
    so_capacity: int = Field(default=5)
    clustering_algorithm: str = Field(default="kmeans", description="Clustering algorithm")
    algorithms: Optional[List[str]] = Field(default=None, description="Algorithms to compare (default: all)")
    local_search_type: Optional[str] = Field(default=None, description="Local search type for all algorithms")


class AlgorithmResult(BaseModel):
    """Result from a single algorithm"""
    algorithm: str
    success: bool
    total_vehicles: int
    total_duration_minutes: float
    execution_time_seconds: float
    routes: List[VehicleRoute]
    error_message: Optional[str] = None


class CompareResponse(BaseModel):
    """Response for algorithm comparison"""
    success: bool
    results: List[AlgorithmResult]
    best_algorithm: str = Field(description="Algorithm with lowest total duration")
    fastest_algorithm: str = Field(description="Algorithm with fastest execution")
    summary: Dict[str, Dict[str, float]] = Field(description="Summary comparison table")


class StrategyInfo(BaseModel):
    """Information about an algorithm strategy"""
    name: str
    display_name: str
    description: str
    complexity: str = Field(default="N/A")
    recommended: bool = Field(default=False)
    supports_local_search: bool = Field(default=False, description="Whether this strategy supports configurable local search")
