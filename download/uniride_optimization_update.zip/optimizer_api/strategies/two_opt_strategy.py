"""
Two-Opt Strategy for TSP/CVRP
Dedicated strategy using local search as the primary optimization method.

This strategy is particularly effective for:
- Small to medium sized problems
- Problems requiring quick optimization
- Refinement of solutions from other algorithms

Features:
- Multi-start optimization for better solution quality
- Configurable local search type (2-opt, 3-opt, Or-opt, Hybrid)
- Optional intensification phase
"""

import random
import time
from typing import List, Dict, Tuple, Optional

from models.schemas import (
    OptimizationRequest, OptimizationResponse,
    VehicleRoute, RouteStep
)
from strategies.base_strategy import BaseRoutingStrategy
from utils.data_loader import DataLoader, haversine_distance, estimate_travel_time
from utils.clustering import VehicleCalculator
from utils.local_search import (
    LocalSearchType, apply_local_search, create_cost_function
)


class TwoOptStrategy(BaseRoutingStrategy):
    """
    Two-Opt based optimization strategy for Vehicle Routing Problem.
    
    Uses K-Means clustering for multi-vehicle routing,
    then applies local search (primarily 2-opt) for TSP optimization.
    
    Features:
    - Multi-start optimization: Runs from multiple random initial solutions
    - Configurable local search type
    - Effective for small to medium problems
    """
    
    # Default parameters
    DEFAULT_CONFIG = {
        "local_search_type": "two_opt",     # Type of local search
        "multi_start": True,                # Enable multi-start optimization
        "num_starts": 5,                    # Number of random starts
        "max_iterations": 30,               # Max iterations per local search
        "intensification": True,            # Final intensification phase
        "seed": None
    }
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = {**self.DEFAULT_CONFIG, **(config or {})}
        self.seed = self.config.get("seed") or int(time.time() * 1000)
        self.rng = random.Random(self.seed)
    
    @property
    def name(self) -> str:
        return "two_opt"
    
    @property
    def display_name(self) -> str:
        return "2-Opt Lokal Arama"
    
    @property
    def description(self) -> str:
        return "Klasik 2-opt tabanlı lokal arama. Hızlı ve etkili."
    
    def _get_local_search_type(self) -> LocalSearchType:
        """Get local search type from config"""
        ls_type = self.config.get("local_search_type", "two_opt")
        try:
            return LocalSearchType(ls_type)
        except ValueError:
            return LocalSearchType.TWO_OPT
    
    def _get_duration(self, from_loc: str, to_loc: str, 
                      time_matrix: Dict, coordinates: Dict) -> float:
        """Get travel duration between two locations"""
        if from_loc in time_matrix and to_loc in time_matrix[from_loc]:
            return time_matrix[from_loc][to_loc]
        
        if from_loc in coordinates and to_loc in coordinates:
            c1 = coordinates[from_loc]
            c2 = coordinates[to_loc]
            dist = haversine_distance(c1["lat"], c1["lng"], c2["lat"], c2["lng"])
            return estimate_travel_time(dist)
        
        return 15.0
    
    def _calculate_route_duration(
        self,
        position: List[str],
        depot: str,
        time_matrix: Dict,
        coordinates: Dict
    ) -> float:
        """Calculate total route duration for a position (permutation)"""
        if not position:
            return 0.0
        
        total = self._get_duration(depot, position[0], time_matrix, coordinates)
        
        for i in range(len(position) - 1):
            total += self._get_duration(
                position[i], position[i + 1], time_matrix, coordinates
            )
        
        total += self._get_duration(position[-1], depot, time_matrix, coordinates)
        return total
    
    def _shuffle(self, items: List) -> List:
        """Fisher-Yates shuffle using internal RNG"""
        result = items.copy()
        for i in range(len(result) - 1, 0, -1):
            j = self.rng.randint(0, i)
            result[i], result[j] = result[j], result[i]
        return result
    
    def _generate_initial_solution(
        self,
        waypoints: List[str],
        method: str = "random"
    ) -> List[str]:
        """
        Generate an initial solution.
        
        Methods:
        - random: Random permutation
        - nearest_neighbor: Nearest neighbor heuristic
        """
        if method == "nearest_neighbor":
            # Nearest neighbor from depot (simplified)
            return self._shuffle(waypoints)  # For now, use random
        else:
            return self._shuffle(waypoints)
    
    def _solve_tsp(
        self,
        waypoints: List[str],
        depot: str,
        time_matrix: Dict,
        coordinates: Dict
    ) -> Tuple[List[str], float]:
        """
        Solve TSP for a single vehicle using 2-opt and local search.
        """
        if not waypoints:
            return [], 0.0
        
        if len(waypoints) == 1:
            duration = (
                self._get_duration(depot, waypoints[0], time_matrix, coordinates) +
                self._get_duration(waypoints[0], depot, time_matrix, coordinates)
            )
            return waypoints, duration
        
        if len(waypoints) == 2:
            # Only 2 permutations possible
            d1 = self._calculate_route_duration(waypoints, depot, time_matrix, coordinates)
            d2 = self._calculate_route_duration(
                [waypoints[1], waypoints[0]], depot, time_matrix, coordinates
            )
            if d1 <= d2:
                return waypoints, d1
            return [waypoints[1], waypoints[0]], d2
        
        # Create cost function
        cost_function = create_cost_function(
            depot, time_matrix, coordinates, self._get_duration
        )
        
        # Get local search type
        ls_type = self._get_local_search_type()
        
        best_route = None
        best_cost = float('inf')
        
        if self.config["multi_start"]:
            # Multi-start optimization
            num_starts = self.config["num_starts"]
            
            for start_idx in range(num_starts):
                # Generate initial solution
                initial_route = self._generate_initial_solution(
                    waypoints, 
                    "random" if start_idx < num_starts - 1 else "nearest_neighbor"
                )
                
                # Apply local search
                improved_route, cost = apply_local_search(
                    initial_route,
                    cost_function,
                    ls_type,
                    self.config["max_iterations"]
                )
                
                if cost < best_cost:
                    best_route = improved_route
                    best_cost = cost
        else:
            # Single start
            initial_route = self._shuffle(waypoints)
            best_route, best_cost = apply_local_search(
                initial_route,
                cost_function,
                ls_type,
                self.config["max_iterations"]
            )
        
        # Intensification phase: try all local search types
        if self.config["intensification"] and len(best_route) > 3:
            for intensify_type in [LocalSearchType.OR_OPT, LocalSearchType.THREE_OPT]:
                try:
                    route, cost = apply_local_search(
                        best_route.copy(),
                        cost_function,
                        intensify_type,
                        self.config["max_iterations"] // 2
                    )
                    if cost < best_cost:
                        best_route = route
                        best_cost = cost
                except Exception:
                    pass  # Continue if intensification fails
        
        return best_route, best_cost
    
    def optimize(self, request: OptimizationRequest) -> OptimizationResponse:
        """Main optimization entry point"""
        start_time = time.time()
        
        students = request.students
        depot = request.depot
        
        if not students:
            return OptimizationResponse(
                algorithm_used=self.name,
                success=True,
                routes=[],
                total_vehicles=0,
                execution_time_seconds=time.time() - start_time
            )
        
        # Override config if provided
        if hasattr(request, 'two_opt_config') and request.two_opt_config:
            self.config.update(request.two_opt_config)
            self.rng = random.Random(self.config.get("seed", self.seed))
        
        # Build time matrix and coordinates
        data_loader = DataLoader.get_instance()
        
        location_ids = [depot.id] + [s.location_code for s in students]
        raw_matrix = data_loader.get_submatrix(location_ids)
        time_matrix = {
            location_ids[i]: {
                location_ids[j]: raw_matrix[i][j]
                for j in range(len(location_ids))
            }
            for i in range(len(location_ids))
        }
        
        coordinates = {depot.id: {"lat": depot.lat, "lng": depot.lng}}
        for s in students:
            coords = s.coordinates or {"lat": 0, "lng": 0}
            coordinates[s.location_code] = coords
        
        # Convert students
        student_dicts = []
        for s in students:
            student_dicts.append({
                "id": s.id,
                "name": s.name,
                "location_code": s.location_code,
                "coordinates": s.coordinates or {"lat": 0, "lng": 0},
                "disability_type": s.disability_type
            })
        
        # Calculate vehicle assignments using VehicleCalculator
        calculator = VehicleCalculator(
            sw_capacity=request.sw_capacity,
            so_capacity=request.so_capacity,
            max_tour_time=request.max_travel_time
        )
        
        def route_optimizer(location_codes: List[str]) -> Dict:
            if not location_codes:
                return {"route_details": [], "total_duration": 0}
            
            optimized_route, duration = self._solve_tsp(
                location_codes, depot.id, time_matrix, coordinates
            )
            
            route_details = []
            current = depot.id
            
            for loc in optimized_route:
                d = self._get_duration(current, loc, time_matrix, coordinates)
                route_details.append({
                    "location1": current,
                    "location2": loc,
                    "duration": d
                })
                current = loc
            
            d = self._get_duration(current, depot.id, time_matrix, coordinates)
            route_details.append({
                "location1": current,
                "location2": depot.id,
                "duration": d
            })
            
            return {"route_details": route_details, "total_duration": duration}
        
        result = calculator.calculate(student_dicts, route_optimizer)
        
        # Build response
        routes = []
        for assignment in result["assignments"]:
            route_steps = [
                RouteStep(
                    location1=step["location1"],
                    location2=step["location2"],
                    duration=round(step["duration"], 2),
                    distance=0.0
                )
                for step in assignment["route"]
            ]
            
            routes.append(VehicleRoute(
                vehicle_id=f"Araç {assignment['vehicle_index']} (2-Opt)",
                route_details=route_steps,
                total_duration_minutes=round(assignment["total_duration"], 2),
                total_distance_km=0.0,
                sw_count=assignment["sw_count"],
                so_count=assignment["so_count"],
                student_ids=[s["id"] for s in assignment["students"]]
            ))
        
        execution_time = time.time() - start_time
        
        return OptimizationResponse(
            algorithm_used=self.name,
            success=True,
            routes=routes,
            total_vehicles=len(routes),
            total_duration_minutes=sum(r.total_duration_minutes for r in routes),
            execution_time_seconds=round(execution_time, 4)
        )
