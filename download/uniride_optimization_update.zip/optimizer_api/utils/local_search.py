"""
Local Search Utilities for TSP/CVRP Optimization

Implements classical local search operators:
- 2-opt: Reverse segments to eliminate crossings
- 3-opt: More powerful variant with 7 possible reconnections
- Or-opt: Relocate sequences of 1-3 consecutive nodes
- Hybrid: Combines multiple operators

References:
- Lin, S. (1965). Computer solutions of the traveling salesman problem.
- Or, I. (1976). Traveling salesman-type combinatorial problems.
"""

from typing import List, Dict, Tuple, Callable, Optional
from enum import Enum
import random
import time


class LocalSearchType(str, Enum):
    """Available local search types"""
    TWO_OPT = "two_opt"
    THREE_OPT = "three_opt"
    OR_OPT = "or_opt"
    HYBRID = "hybrid"
    NONE = "none"


class TwoOpt:
    """
    2-opt local search operator.
    
    Reverses segments to eliminate edge crossings.
    Time complexity: O(n²) per iteration
    
    Reference:
    Lin, S. (1965). Computer solutions of the traveling salesman problem.
    Bell System Technical Journal, 44(10), 2245-2269.
    """
    
    def __init__(self, max_iterations: int = 20):
        self.max_iterations = max_iterations
    
    def improve(
        self,
        route: List[str],
        cost_function: Callable[[List[str]], float]
    ) -> Tuple[List[str], float]:
        """
        Apply 2-opt improvement to a route.
        
        Args:
            route: Current route (permutation of locations)
            cost_function: Function that calculates route cost
            
        Returns:
            Tuple of (improved_route, best_cost)
        """
        if len(route) < 3:
            return route, cost_function(route)
        
        best_route = route.copy()
        best_cost = cost_function(best_route)
        improved = True
        iteration = 0
        
        while improved and iteration < self.max_iterations:
            improved = False
            iteration += 1
            n = len(best_route)
            
            for i in range(n - 1):
                for j in range(i + 2, n):
                    # Try reversing segment [i+1:j]
                    new_route = (
                        best_route[:i + 1] +
                        best_route[i + 1:j + 1][::-1] +
                        best_route[j + 1:]
                    )
                    
                    new_cost = cost_function(new_route)
                    
                    if new_cost < best_cost:
                        best_route = new_route
                        best_cost = new_cost
                        improved = True
        
        return best_route, best_cost


class ThreeOpt:
    """
    3-opt local search operator.
    
    Removes 3 edges and reconnects in the best of 7 possible ways.
    More powerful than 2-opt but slower.
    Time complexity: O(n³) per iteration
    
    Reference:
    Lin, S. (1965). Computer solutions of the traveling salesman problem.
    """
    
    def __init__(self, max_iterations: int = 10):
        self.max_iterations = max_iterations
    
    def _get_reconnections(
        self,
        route: List[str],
        i: int,
        j: int,
        k: int
    ) -> List[List[str]]:
        """
        Generate all 7 possible 3-opt reconnections (excluding original).
        
        Given cuts at positions i, j, k, we have segments:
        A = route[0:i+1], B = route[i+1:j+1], C = route[j+1:k+1], D = route[k+1:]
        
        The 7 reconnections are:
        1. A-B'-C-D  (2-opt on B)
        2. A-B-C'-D  (2-opt on C)
        3. A-B'-C'-D (2-opt on B and C)
        4. A-C-B-D   (swap B and C)
        5. A-C-B'-D  (swap and reverse B)
        6. A-C'-B-D  (swap and reverse C)
        7. A-C'-B'-D (swap and reverse both)
        """
        n = len(route)
        A = route[:i + 1]
        B = route[i + 1:j + 1]
        C = route[j + 1:k + 1]
        D = route[k + 1:]
        
        # All possible reconnections (excluding original A-B-C-D)
        reconnections = [
            A + B[::-1] + C + D,      # Reverse B
            A + B + C[::-1] + D,      # Reverse C
            A + B[::-1] + C[::-1] + D,  # Reverse both B and C
            A + C + B + D,            # Swap B and C
            A + C + B[::-1] + D,      # Swap, reverse B
            A + C[::-1] + B + D,      # Swap, reverse C
            A + C[::-1] + B[::-1] + D,  # Swap, reverse both
        ]
        
        return reconnections
    
    def improve(
        self,
        route: List[str],
        cost_function: Callable[[List[str]], float]
    ) -> Tuple[List[str], float]:
        """
        Apply 3-opt improvement to a route.
        
        Args:
            route: Current route
            cost_function: Function that calculates route cost
            
        Returns:
            Tuple of (improved_route, best_cost)
        """
        if len(route) < 4:
            # Fall back to 2-opt for small routes
            return TwoOpt().improve(route, cost_function)
        
        best_route = route.copy()
        best_cost = cost_function(best_route)
        improved = True
        iteration = 0
        
        while improved and iteration < self.max_iterations:
            improved = False
            iteration += 1
            n = len(best_route)
            
            for i in range(n - 3):
                for j in range(i + 2, n - 2):
                    for k in range(j + 2, n):
                        # Try all 7 reconnections
                        for new_route in self._get_reconnections(best_route, i, j, k):
                            new_cost = cost_function(new_route)
                            
                            if new_cost < best_cost:
                                best_route = new_route
                                best_cost = new_cost
                                improved = True
                                break
                        
                        if improved:
                            break
                    if improved:
                        break
        
        return best_route, best_cost


class OrOpt:
    """
    Or-opt local search operator.
    
    Relocates sequences of 1-3 consecutive nodes to better positions.
    Good for route refinement after 2-opt.
    Time complexity: O(n²) per iteration
    
    Reference:
    Or, I. (1976). Traveling salesman-type combinatorial problems and
    their relation to the logistics of blood banking.
    """
    
    def __init__(self, max_iterations: int = 15, max_seq_length: int = 3):
        self.max_iterations = max_iterations
        self.max_seq_length = max_seq_length
    
    def improve(
        self,
        route: List[str],
        cost_function: Callable[[List[str]], float]
    ) -> Tuple[List[str], float]:
        """
        Apply Or-opt improvement to a route.
        
        Args:
            route: Current route
            cost_function: Function that calculates route cost
            
        Returns:
            Tuple of (improved_route, best_cost)
        """
        if len(route) < 4:
            return route, cost_function(route)
        
        best_route = route.copy()
        best_cost = cost_function(best_route)
        improved = True
        iteration = 0
        
        while improved and iteration < self.max_iterations:
            improved = False
            iteration += 1
            n = len(best_route)
            
            # Try relocating sequences of different lengths
            for seq_len in range(1, min(self.max_seq_length + 1, n)):
                for i in range(n - seq_len + 1):
                    # Extract the sequence
                    sequence = best_route[i:i + seq_len]
                    remaining = best_route[:i] + best_route[i + seq_len:]
                    
                    # Try inserting at each position
                    for j in range(len(remaining) + 1):
                        if j == i:
                            continue  # Skip original position
                        
                        # Insert sequence at position j
                        new_route = remaining[:j] + sequence + remaining[j:]
                        new_cost = cost_function(new_route)
                        
                        if new_cost < best_cost:
                            best_route = new_route
                            best_cost = new_cost
                            improved = True
                            break
                    
                    if improved:
                        break
                if improved:
                    break
        
        return best_route, best_cost


class HybridLocalSearch:
    """
    Hybrid local search combining multiple operators.
    
    Applies operators in sequence for best results:
    1. 2-opt for eliminating crossings
    2. Or-opt for relocating sequences
    3. Optional 3-opt for final refinement
    
    This approach leverages the strengths of each operator.
    """
    
    def __init__(
        self,
        max_iterations_2opt: int = 15,
        max_iterations_oropt: int = 10,
        max_iterations_3opt: int = 5,
        use_3opt: bool = True
    ):
        self.two_opt = TwoOpt(max_iterations_2opt)
        self.or_opt = OrOpt(max_iterations_oropt)
        self.use_3opt = use_3opt
        self.three_opt = ThreeOpt(max_iterations_3opt) if use_3opt else None
    
    def improve(
        self,
        route: List[str],
        cost_function: Callable[[List[str]], float]
    ) -> Tuple[List[str], float]:
        """
        Apply hybrid local search to a route.
        
        Args:
            route: Current route
            cost_function: Function that calculates route cost
            
        Returns:
            Tuple of (improved_route, best_cost)
        """
        # Phase 1: 2-opt
        current_route, current_cost = self.two_opt.improve(route, cost_function)
        
        # Phase 2: Or-opt
        current_route, current_cost = self.or_opt.improve(current_route, cost_function)
        
        # Phase 3: 3-opt (optional, for final refinement)
        if self.use_3opt and len(current_route) >= 4:
            current_route, current_cost = self.three_opt.improve(current_route, cost_function)
        
        return current_route, current_cost


def apply_local_search(
    route: List[str],
    cost_function: Callable[[List[str]], float],
    local_search_type: LocalSearchType = LocalSearchType.TWO_OPT,
    max_iterations: int = 20
) -> Tuple[List[str], float]:
    """
    Apply the specified local search operator to improve a route.
    
    Args:
        route: Current route
        cost_function: Function that calculates route cost
        local_search_type: Type of local search to apply
        max_iterations: Maximum iterations for the search
        
    Returns:
        Tuple of (improved_route, best_cost)
    """
    if local_search_type == LocalSearchType.NONE or len(route) < 3:
        return route, cost_function(route)
    
    if local_search_type == LocalSearchType.TWO_OPT:
        operator = TwoOpt(max_iterations)
        return operator.improve(route, cost_function)
    
    if local_search_type == LocalSearchType.THREE_OPT:
        operator = ThreeOpt(max_iterations // 2)  # 3-opt is slower
        return operator.improve(route, cost_function)
    
    if local_search_type == LocalSearchType.OR_OPT:
        operator = OrOpt(max_iterations)
        return operator.improve(route, cost_function)
    
    if local_search_type == LocalSearchType.HYBRID:
        operator = HybridLocalSearch(
            max_iterations_2opt=max_iterations,
            max_iterations_oropt=max_iterations // 2,
            use_3opt=True
        )
        return operator.improve(route, cost_function)
    
    # Default to 2-opt
    operator = TwoOpt(max_iterations)
    return operator.improve(route, cost_function)


def create_cost_function(
    depot: str,
    time_matrix: Dict,
    coordinates: Dict,
    get_duration_func: Callable[[str, str, Dict, Dict], float]
) -> Callable[[List[str]], float]:
    """
    Create a cost function for local search.
    
    Args:
        depot: Depot location ID
        time_matrix: Time matrix dictionary
        coordinates: Coordinates dictionary
        get_duration_func: Function to get duration between two locations
        
    Returns:
        Cost function that takes a route and returns total duration
    """
    def cost_function(route: List[str]) -> float:
        if not route:
            return 0.0
        
        total = get_duration_func(depot, route[0], time_matrix, coordinates)
        
        for i in range(len(route) - 1):
            total += get_duration_func(route[i], route[i + 1], time_matrix, coordinates)
        
        total += get_duration_func(route[-1], depot, time_matrix, coordinates)
        return total
    
    return cost_function


# Export all
__all__ = [
    'LocalSearchType',
    'TwoOpt',
    'ThreeOpt',
    'OrOpt',
    'HybridLocalSearch',
    'apply_local_search',
    'create_cost_function'
]
