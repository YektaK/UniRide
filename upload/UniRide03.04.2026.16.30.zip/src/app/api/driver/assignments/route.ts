import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { createClient } from "@supabase/supabase-js";

// Create Supabase client with service role for admin operations
const supabaseAdmin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// Verify JWT and get user
async function verifyAuth(authHeader: string | null) {
    if (!authHeader?.startsWith("Bearer ")) {
        return null;
    }

    const token = authHeader.split(" ")[1];

    const { data: { user }, error } = await supabaseAdmin.auth.getUser(token);

    if (error || !user) {
        return null;
    }

    // Get user profile to check role
    const { data: profile } = await supabaseAdmin
        .from("users")
        .select("*")
        .eq("id", user.id)
        .single();

    return profile;
}

export async function GET() {
    try {
        const headersList = await headers();
        const authHeader = headersList.get("authorization");

        const user = await verifyAuth(authHeader);

        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (user.role !== "driver" && user.role !== "admin") {
            return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }

        // Get route assignments for this driver
        let query = supabaseAdmin
            .from("route_assignments")
            .select("*")
            .order("pickup_time", { ascending: true });

        // If driver, filter by their ID only
        if (user.role === "driver") {
            query = query.eq("driver_id", user.id);
        }

        const { data, error } = await query;

        if (error) {
            console.error("Error fetching assignments:", error);
            return NextResponse.json({ error: error.message }, { status: 500 });
        }

        // Transform snake_case to camelCase
        const assignments = (data || []).map((assignment: any) => ({
            id: assignment.id,
            date: assignment.date,
            vehicleId: assignment.vehicle_id,
            driverId: assignment.driver_id,
            routeId: assignment.route_id,
            studentIds: assignment.student_ids || [],
            pickupTime: assignment.pickup_time,
            estimatedDropoffTime: assignment.estimated_dropoff_time,
            status: assignment.status,
            createdAt: assignment.created_at,
            updatedAt: assignment.updated_at,
        }));

        return NextResponse.json(assignments);
    } catch (error: any) {
        console.error("Driver assignments API error:", error);
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}

export async function PUT(request: Request) {
    try {
        const headersList = await headers();
        const authHeader = headersList.get("authorization");

        const user = await verifyAuth(authHeader);

        if (!user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (user.role !== "driver") {
            return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }

        const body = await request.json();
        const { id, status } = body;

        if (!id || !status) {
            return NextResponse.json({ error: "Missing id or status" }, { status: 400 });
        }

        // Drivers can only update status of their own assignments
        const { data: existingAssignment } = await supabaseAdmin
            .from("route_assignments")
            .select("driver_id")
            .eq("id", id)
            .single();

        if (!existingAssignment || existingAssignment.driver_id !== user.id) {
            return NextResponse.json({ error: "Assignment not found or not authorized" }, { status: 404 });
        }

        // Only allow certain status transitions
        const allowedStatuses = ["in_progress", "completed"];
        if (!allowedStatuses.includes(status)) {
            return NextResponse.json({ error: "Invalid status" }, { status: 400 });
        }

        const { data, error } = await supabaseAdmin
            .from("route_assignments")
            .update({
                status,
                updated_at: new Date().toISOString()
            })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            console.error("Error updating assignment:", error);
            return NextResponse.json({ error: error.message }, { status: 500 });
        }

        return NextResponse.json({
            id: data.id,
            status: data.status,
            message: "Assignment updated successfully"
        });
    } catch (error: any) {
        console.error("Driver assignments API error:", error);
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}
